#' Four points illustrating the lower bound of the truncated LPM, on a skew-T
#'
#' Builds the four reference points used to explain where the saturated LPM
#' integrals are truncated, from a pseudo-sounding:
#'   - "state"   : mixed-layer parcel state    (p_sfc, T_par)
#'   - "dewpoint": mixed-layer parcel dew point (p_sfc, Td_par)
#'   - "lcl_parcel" : parcel LCL (Romps)        (p_LCL, T_LCL_parcel)
#'   - "lcl_env"    : environment at the LCL    (p_LCL, T_env(p_LCL))   <- LPM bound
#'
#' The mixed layer is the dP_ML (default 100 hPa) of air above the surface, and
#' the parcel is its mass-weighted mean theta / mixing ratio, consistent with
#' vertical_integrals_lpm.R. Requires moistR loaded (cst, esat, LCL).
#'
#' @param sounding data.frame with columns p (Pa), T (K), Td (K), surface first
#'                 (highest pressure) or any order; sorted internally.
#' @param dP_ML mixed-layer depth in Pa (default 100 hPa)
#' @return data.frame with columns point, p (Pa), T (K), ready for geom_skewT_point()
#' @import ggplot2
#' @export
lpm_lower_bound_points <- function(sounding, dP_ML = 100 * 100) {

  eps   <- cst$Rd / cst$Rv
  kappa <- cst$Rd / cst$cpd
  p0    <- 1e5

  # --- tri surface -> sommet (pression decroissante) ---
  o   <- order(sounding$p, decreasing = TRUE)
  p   <- sounding$p[o]
  Tk  <- sounding$T[o]
  Td  <- sounding$Td[o]
  nlev <- length(p)

  p_sfc <- p[1]; T_sfc <- Tk[1]; Td_sfc <- Td[1]

  # rapport de melange de surface depuis le point de rosee
  e_sfc <- esat(Td_sfc, "liquid")
  q_sfc <- eps * e_sfc / (p_sfc - (1 - eps) * e_sfc)
  r_sfc <- q_sfc / (1 - q_sfc)
  th_sfc <- T_sfc * (p0 / p_sfc)^kappa

  # --- moyenne couche-melange (ponderee dp) de theta et r ---
  topML <- p_sfc - dP_ML
  th_acc <- 0; r_acc <- 0; w_tot <- 0
  pp <- p_sfc; pth <- th_sfc; pr <- r_sfc
  for (k in seq_len(nlev)) {
    inML <- (p[k] < p_sfc) & (p[k] >= topML)
    if (!inML) next
    e_k  <- esat(Td[k], "liquid")
    q_k  <- eps * e_k / (p[k] - (1 - eps) * e_k)
    r_k  <- q_k / (1 - q_k)
    th_k <- Tk[k] * (p0 / p[k])^kappa
    dp   <- pp - p[k]
    th_acc <- th_acc + 0.5 * (pth + th_k) * dp
    r_acc  <- r_acc  + 0.5 * (pr  + r_k ) * dp
    w_tot  <- w_tot  + dp
    pp <- p[k]; pth <- th_k; pr <- r_k
  }
  th_bar <- if (w_tot > 0) th_acc / w_tot else th_sfc
  r_bar  <- if (w_tot > 0) r_acc  / w_tot else r_sfc

  # --- point d'etat et de rosee de la parcelle, ramenes a p_sfc ---
  T_par  <- th_bar * (p_sfc / p0)^kappa
  e_par  <- p_sfc * r_bar / (eps + r_bar)        # pression de vapeur de la parcelle
  Td_par <- DewPoint(e_par, tol = 1e-3)          # K

  # --- LCL de parcelle (Romps) ---
  res          <- LCL(p_sfc, T_par, r_bar, extras = TRUE)
  p_LCL        <- res$p_LCL
  T_LCL_parcel <- res$T_LCL

  # --- temperature environnementale interpolee a p_LCL ---
  # interpolation lineaire en p sur le sondage (p decroissant)
  kk    <- findInterval(-p_LCL, -p)              # p[kk] >= p_LCL > p[kk+1]
  kk    <- min(max(kk, 1L), nlev - 1L)
  w     <- (p[kk] - p_LCL) / (p[kk] - p[kk + 1])
  T_env_LCL <- Tk[kk] + (Tk[kk + 1] - Tk[kk]) * w

  data.frame(
    point = c("state", "dewpoint", "lcl_parcel", "lcl_env"),
    p     = c(p_sfc,   p_sfc,      p_LCL,        p_LCL),
    T     = c(T_par,   Td_par,     T_LCL_parcel, T_env_LCL),
    stringsAsFactors = FALSE
  )
}
