cst <- new.env()

# Accélération de la gravité (m.s-2)
cst$g <- 9.81
# Pression standard (Pa)
cst$pstd <- 1.e5
# Constante de gaz spécifique de l'air sec (J.kg-1.K-1)
cst$Rd <- 287.04
# Capacite thermique massique isochore de l'air sec (J.kg-1.K-1)
cst$cvd <- 719.
# Capacite thermique massique isobare de l'air sec (J.kg-1.K-1)
cst$cpd <- cst$cvd + cst$Rd
# Ratio Rd/cpd
cst$kappad <- cst$Rd/cst$cpd
# Constante de gaz spécifique de la vapeur d'eau (J.kg-1.K-1)
cst$Rv <- 461.
# Capacite thermique massique isochore de la vapeur d'eau (J.kg-1.K-1)
cst$cvv <- 1418.
# Capacite thermique massique isobare de la vapeur d'eau (J.kg-1.K-1)
cst$cpv <- cst$cvv + cst$Rv
# Ratio Rd/Rv
cst$eps <- cst$Rd/cst$Rv
# Capacite thermique massique de l'eau liquide (J.kg-1.K-1)
cst$cpl <- 4119.
# Capacite thermique massique de la glace (J.kg-1.K-1)
cst$cps <- 1861.
# Pression du point triple de l'eau (Pa)
cst$ptrip <- 611.65
# Température du point triple de l'eau (K)
cst$Ttrip <- 273.16
# Enthalpie spécifique de vaporisation de l'eau à Ttrip (J.kg-1)
cst$DvapH0 <- 2.4999e6
# Enthalpie spécifique de sublimation de la glace à Ttrip (J.kg-1)
cst$DsubH0 <- cst$DvapH0 + 0.3337e6
