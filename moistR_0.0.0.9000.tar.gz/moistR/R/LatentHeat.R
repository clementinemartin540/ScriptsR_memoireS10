#' Latent heat of phase change
#'
#' @param T values of temperature in K
#' @param condens character string: if starts with "L" or "l", condensed phase is assumed
#'   to be liquid. If starts with "S" or "s", condensed phase is assumed to be solid.
#'   Otherwise, automatic selection is made using temperature value.
#'
#' @importFrom terra ifel
#' @return specific enthalpy of phase change (J/kg), same type and size as T
#' @export
LatentHeat <- function(T, condens = "l") {

  L_liq <- cst$DvapH0 + (cst$cpv - cst$cpl) * (T - cst$Ttrip)

  if (substr(tolower(condens), 1, 1) == "l") return(L_liq)

  L_ice <- cst$DsubH0 + (cst$cpv - cst$cps) * (T - cst$Ttrip)

  terra::ifel(T >= cst$Ttrip, L_liq, L_ice)
}
