#' ODE defining the saturated pseudoadiabatic path
#' Returns the terms F_T(p,T) and F_p(p,T) such that F_T * dT/T = F_p dp/p along the pseudoadiabat
#'
#' @param p values of pressure (Pa)
#' @param T values of temperature (K)
#' @param liq boolean values, where TRUE, the saturation vapor pressure with respect to liquid water is used, elsewhere the saturation vapor pressure with respect to ice is used.
#'
#' @return a list
#' @export
SPA_EDO_symm <- function(p,T,liq)
{
  # p : pressure
  # T : temperature
  #
  # rs : saturation mixing ratio at (p,T) in kg/kg

  # retour : (F_p,F_T,rs,Gamma_m)

  # Calcul de la chaleur latent de vaporisation
  L <- NA_real_ * p
  L[liq] <- cst$DvapH0 + (cst$cpv-cst$cpl)*(T[liq]-cst$Ttrip) # J/kg
  L[!liq] <- cst$DsubH0 + (cst$cpv-cst$cps)*(T[!liq]-cst$Ttrip) # J/kg

  Es <- NA_real_ * p
  Es <- cst$ptrip*exp((cst$DvapH0-(cst$cpv-cst$cpl)*cst$Ttrip)*(1/cst$Ttrip-T^(-1))/cst$Rv)*(T/cst$Ttrip)^((cst$cpv-cst$cpl)/cst$Rv)
  Es[!liq] <- cst$ptrip*exp((cst$DsubH0-(cst$cpv-cst$cps)*cst$Ttrip)*(1/cst$Ttrip-T[!liq]^(-1))/cst$Rv)*(T[!liq]/cst$Ttrip)^((cst$cpv-cst$cps)/cst$Rv)

  rs <- cst$eps*Es/(p-Es)
  kappam <- cst$kappad*(1+rs/cst$eps)/(1+rs*cst$cpv/cst$cpd)
  X <- L/(cst$Rv*T)

  # F_T(p,T) dT/T = F_p(p,T) dp/p
  F_T <- 1. + (rs/cst$eps)*kappam*(X^2)
  F_p <- (1.+(rs/cst$eps)*X)*kappam

  Rm <- (cst$Rd+rs*cst$Rv)/(1+rs)
  Gamma_m <- -cst$g*F_p/(F_T*Rm)

  return(list(F_p = F_p,
              F_T = F_T,
              rs = rs,
              Gamma_m = Gamma_m))
}
