#' Skew-T template diagram for ggplot
#'
#' @param pmin Lower limit for pressure (y) axis
#' @param Tmin Lower limit for temperature (skewed x) axis, in degrees Celsius
#' @param Tmax Upper limit for temperature (skewed x) axis, in degrees Celsius
#' @param size Font size for labels
#'
#' @return a ggplot layer
#' @import ggplot2
#' @import magrittr
#' @importFrom dplyr group_by
#' @importFrom dplyr mutate
#' @importFrom dplyr filter
#' @importFrom dplyr ungroup
#' @importFrom rlang ensym
#' @importFrom grDevices rgb
#' @importFrom stats lag
#' @export
geom_skewT_template <- function(pmin=100,Tmin=-30,Tmax=50,size=2)
{
  pmin <- 10*round(pmin/10)

  # Clipping d'une polyligne contre la fenetre [xlim] x [ylim], VECTORISE.
  # Chaque arete (i -> i+1) est coupee contre les 4 bords par Liang-Barsky.
  # Tout est calcule en colonnes (pas de rbind en boucle, qui etait quadratique
  # et causait un gel sur les courbes denses). On produit au plus 2 points par
  # arete visible (entree/sortie sur les bords) ; les segments sont identifies
  # par une numerotation vectorisee des ruptures de continuite.
  cut_paths_to_view <- function(df, xlim, ylim, group_col) {
    group_col <- rlang::ensym(group_col)
    gname     <- rlang::as_string(group_col)

    clip_one <- function(g) {
      n <- nrow(g)
      if (n == 0L) return(g[0, , drop = FALSE])
      if (n == 1L) {
        ins <- !anyNA(c(g$x[1], g$y[1])) &
               g$x[1] >= xlim[1] & g$x[1] <= xlim[2] &
               g$y[1] >= ylim[1] & g$y[1] <= ylim[2]
        if (isTRUE(ins)) { g$group_segment <- paste0(g[[gname]][1], "_1"); return(g) }
        return(cbind(g[0, , drop = FALSE], group_segment = character(0)))
      }

      # aretes : indices de depart 1..n-1
      x0 <- g$x[-n]; y0 <- g$y[-n]
      x1 <- g$x[-1]; y1 <- g$y[-1]
      dx <- x1 - x0; dy <- y1 - y0

      # Liang-Barsky vectorise : pour chaque bord, p et q par arete
      P <- cbind(-dx, dx, -dy, dy)
      Q <- cbind(x0 - xlim[1], xlim[2] - x0, y0 - ylim[1], ylim[2] - y0)

      tin  <- rep(0,  n - 1L)
      tout <- rep(1,  n - 1L)
      keep <- !is.na(dx) & !is.na(dy) & !is.na(x0) & !is.na(y0)  # arete sans NA

      for (b in 1:4) {
        p <- P[, b]; q <- Q[, b]
        par_out <- (p == 0) & (q < 0)          # parallele et dehors
        par_out[is.na(par_out)] <- FALSE       # arete NA -> pas "parallele dehors"
        keep <- keep & !par_out
        moving <- p != 0
        moving[is.na(moving)] <- FALSE          # arete NA -> non traitee ici
        r <- ifelse(moving, q / p, NA_real_)
        neg <- moving & (p < 0); neg[is.na(neg)] <- FALSE
        pos <- moving & (p > 0); pos[is.na(pos)] <- FALSE
        tin[neg]  <- pmax(tin[neg],  r[neg])
        tout[pos] <- pmin(tout[pos], r[pos])
      }
      vis <- keep & (tin <= tout)              # arete avec portion visible
      vis[is.na(vis)] <- FALSE

      if (!any(vis)) return(cbind(g[0, , drop = FALSE], group_segment = character(0)))

      idx <- which(vis)
      xa <- x0[idx] + tin[idx]  * dx[idx]; ya <- y0[idx] + tin[idx]  * dy[idx]
      xb <- x0[idx] + tout[idx] * dx[idx]; yb <- y0[idx] + tout[idx] * dy[idx]
      exits_clean <- tout[idx] >= 1            # ressort par le point i+1 (continuite)

      # numerotation des segments : nouveau segment quand l'arete visible
      # precedente n'etait pas contigue (saut d'indice) ou ne ressortait pas
      # proprement (tout < 1 -> coupure au bord).
      gap        <- c(TRUE, diff(idx) != 1L)               # arete non contigue
      prev_clean <- c(FALSE, exits_clean[-length(exits_clean)])
      new_seg    <- gap | !prev_clean
      seg_id     <- cumsum(new_seg)

      # Construction des points sans rbind incremental :
      # pour chaque arete visible on emet le point d'entree SI nouveau segment,
      # et toujours le point de sortie. On bâtit les vecteurs d'un coup.
      emit_entry <- new_seg
      np <- sum(emit_entry) + length(idx)      # nb total de points

      px <- numeric(np); py <- numeric(np); pseg <- integer(np); psrc <- integer(np)
      pos <- 1L
      # entrees (vectorise)
      ie <- which(emit_entry)
      ne <- length(ie)
      if (ne > 0L) {
        rng <- pos:(pos + ne - 1L)
        px[rng] <- xa[ie]; py[rng] <- ya[ie]
        pseg[rng] <- seg_id[ie]; psrc[rng] <- idx[ie]
        pos <- pos + ne
      }
      # sorties (toutes les aretes visibles)
      rng <- pos:(pos + length(idx) - 1L)
      px[rng] <- xb; py[rng] <- yb
      pseg[rng] <- seg_id; psrc[rng] <- idx

      # ordre : entree d'une arete avant sa sortie, et aretes dans l'ordre.
      # On trie par (source d'arete, type) : entree (0) avant sortie (1).
      typ <- c(rep(0L, ne), rep(1L, length(idx)))
      ord <- order(psrc, typ)
      px <- px[ord]; py <- py[ord]; pseg <- pseg[ord]; psrc <- psrc[ord]

      # propage les colonnes annexes (lw, group...) depuis le point de depart i
      base <- g[psrc, , drop = FALSE]
      base$x <- px; base$y <- py
      base$group_segment <- paste0(g[[gname]][1], "_", pseg)
      rownames(base) <- NULL
      base
    }

    parts <- lapply(split(df, df[[gname]]), clip_one)
    res   <- do.call(rbind, parts)
    if (is.null(res) || nrow(res) == 0L) {
      res <- cbind(df[0, , drop = FALSE], group_segment = character(0))
    }
    rownames(res) <- NULL
    res
  }

#####################################################################

  scale_x <- 1 # 2.91
  scale_y <- 254.8 / 2.91
  offset_y  <- scale_y*log(1000)/log(10)

  XMIN <- Tmin*scale_x
  XMAX <- Tmax*scale_x
  YMIN <- offset_y-scale_y*log(1050.)/log(10)
  YMAX <- offset_y-scale_y*log(pmin)/log(10)

  p <- seq(pmin,1050,by=10)*1e2
  T <- seq(-80,60);


  ####### Isothermes #######

  T0 <- seq(-80,60)
  # log(0.01*p(:).*.ones(T0))/log(10)
  matp <- log(0.01*outer(p,rep(1,length(T0))))/log(10)

  y <- offset_y-scale_y*matp
  x <- scale_x*outer(rep(1,length(p)),T0)+y
  matT0 <- outer(rep(1,length(p)),T0)

  isotherms <- data.frame(
    x = as.vector(x),
    y = as.vector(y),
    T0 = as.vector(matT0)
  )
  isotherms$lw = ifelse(isotherms$T0 %% 10 == 0,
                 "large",
                 "fine")
  isotherms$lw <- factor(isotherms$lw,levels = c("fine", "large", "thick"))

  isotherms <- cut_paths_to_view(isotherms,
                                 c(XMIN,XMAX),
                                 c(YMIN,YMAX),
                                 group_col = T0)

  bistre = rgb(215/255,150/255,50/255)

  ####### Isobares #######

  matp <- outer(rep(1,2,2),0.01*p)
  y = offset_y-scale_y*log(matp)/log(10)
  xmin = scale_x*(-80)+offset_y-scale_y*log(0.01*p)/log(10)
  xmin = pmax(xmin,Tmin*scale_x)
  x = rbind(matrix(xmin,nrow=1) ,
            Tmax*scale_x*rep(1,1,length(p)) )

  isobars <- data.frame(
    x = as.vector(x),
    y = as.vector(y),
    p = as.vector(matp)
  )
  isobars$lw = ifelse(isobars$p %% 50 == 0,
                        "large",
                        "fine")
  isobars$lw[isobars$p==1000] <- "thick"
  isobars$lw <- factor(isobars$lw,levels = c("fine", "large", "thick"))

  # isobars <- cut_lines_to_view(isobars,
  #                                c(-30,50)*scale_x,
  #                                c(offset_y-scale_y*log(1050.)/log(10) ,
  #                                  offset_y-scale_y*log(pmin)/log(10)),
  #                                group_col = p)

  ####### Iso-rsat ###########

  rsat = c(seq(0.1,1,by=0.1),
           seq(1.2,3,by=0.2),
           seq(3.5,5,by=0.5),
           seq(6,10,by=1),
           seq(12,50,by=2),
           seq(55,80,by=5),
           seq(90,150,by=10))*1e-3

  Esat <- esat(cst$Ttrip+T)
  #if convstr(part(condens,1:1),'l')=='a' then
  #Esat(T<0) = esat(constants.Ttrip+T(T<0)','s');
  #end
  p_r <- outer(Esat,cst$eps/rsat+1)

  y = offset_y-scale_y*log(0.01*p_r)/log(10)
  x = scale_x*outer(T,rep(1,length(rsat)))+y

  matrsat <- outer(rep(1,length(T)),rsat)

  isorsat <- data.frame(
    x = as.vector(x),
    y = as.vector(y),
    rsat = as.vector(matrsat)
  )
  isorsat$lw = "fine"
  boldrsat <- c(0.1,0.5,seq(1,5),seq(10,80,by=10),
    seq(100,140,by=20))*1e-3
  isorsat$lw[isorsat$rsat %in% boldrsat] <- "large"
  isorsat$lw <- factor(isorsat$lw,levels = c("fine", "large", "thick"))

  isorsat <- cut_paths_to_view(isorsat,
                               c(XMIN,XMAX),
                               c(YMIN,YMAX),
                                 group_col = rsat)

  ######### Adiabatiques sèches (r=0) ##############

  T0 = seq(-30,200,by=5)
  T = outer((p/cst$pstd)^cst$kappad,T0+cst$Ttrip) - cst$Ttrip

  y = offset_y-scale_y*log(0.01*outer(p,rep(1,length(T0))))/log(10)
  x = scale_x*T+y
  y[T<=-80]<-NA_real_;
  x[T<=-80]<-NA_real_;
  matT0 <- outer(rep(1,length(p)),T0)

  vert = rgb(80/255,180/255,105/255)
  dryadiabats <- data.frame(
    x = as.vector(x),
    y = as.vector(y),
    T0 = as.vector(matT0)
  )
  dryadiabats$lw = ifelse(dryadiabats$T0 %% 10 == 0,
                      "large",
                      "fine")
  dryadiabats$lw <- factor(dryadiabats$lw,levels = c("fine", "large", "thick"))

  dryadiabats <- cut_paths_to_view(dryadiabats,
                                   c(XMIN,XMAX),
                                   c(YMIN,YMAX),
                                   group_col = T0)

  ######### Adiabatiques saturées (r=0) ##############

  T0 <- seq(-30,60,by=2)
  p0 <- 1000e2*rep(1,length(T0))
  T1 <- (-80)*rep(1,length(T0))
  p1 <- NULL

  result <- SatPseudoAdiabat(p0,T0+cst$Ttrip,
                             p1,T1+cst$Ttrip,Trace=TRUE)
  matT0 <- outer(rep(1,nrow(result$Trace_p)),T0)

  y = offset_y-scale_y*log(0.01*result$Trace_p)/log(10)
  x = scale_x*(result$Trace_T-cst$Ttrip) + y

  moistadiabats_up <- data.frame(
    x = as.vector(x),
    y = as.vector(y),
    T0 = as.vector(matT0)
  )
  moistadiabats_up$lw = ifelse(moistadiabats_up$T0 %% 10 == 0,
                          "large",
                          "fine")
  moistadiabats_up$lw <- factor(moistadiabats_up$lw,levels = c("fine", "large", "thick"))

  moistadiabats_up <- cut_paths_to_view(moistadiabats_up,
                                        c(XMIN,XMAX),
                                        c(YMIN,YMAX),
                                        group_col = T0)
  moistadiabats_up$group_segment <- as.factor(moistadiabats_up$group_segment)

  T1 <- NULL
  p1 <- 1050e2*rep(1,length(T0))

  result <- SatPseudoAdiabat(p0,T0+cst$Ttrip,
                             p1,T1+cst$Ttrip,Trace=TRUE)
  matT0 <- outer(rep(1,nrow(result$Trace_p)),T0)

  y = offset_y-scale_y*log(0.01*result$Trace_p)/log(10)
  x = scale_x*(result$Trace_T-cst$Ttrip) + y

  moistadiabats_down <- data.frame(
    x = as.vector(x),
    y = as.vector(y),
    T0 = as.vector(matT0)
  )
  moistadiabats_down$lw = ifelse(moistadiabats_down$T0 %% 10 == 0,
                               "large",
                               "fine")
  moistadiabats_down$lw <- factor(moistadiabats_down$lw,levels = c("fine", "large", "thick"))

  moistadiabats_down <- cut_paths_to_view(moistadiabats_down,
                                          c(XMIN,XMAX),
                                          c(YMIN,YMAX),
                                          group_col = T0)

  lw_to_num <- function(lw) {
    ifelse(lw == "fine", 0.1,
           ifelse(lw == "large", 0.25,
                  ifelse(lw == "thick", 0.5, NA)))
  }

  ############## Etiquettes ##################

  # isobares

  p <- c(seq(100,300,by=50),seq(400,1000,by=100))*1e2
  p <- p[p>=1e2*pmin]
  y <- offset_y-scale_y*log(0.01*p)/log(10)
  xmin <- pmax(Tmin,scale_x*(-80.) + y)
  xmax <- scale_x*Tmax*rep(1,length(p))

  label_isobars <- data.frame(x=c(xmin,xmax),
                              y=c(y,y),
                              hjust=c(rep(0,length(p)),rep(1,length(p))),
                              label=sprintf("%d",c(p,p)/1e2))

  # isothermes

  T0 = seq(10*ceiling(Tmin/10),10*floor(Tmax/10),by=10)
  y = offset_y-scale_y*rep(1,length(T0))*log(1050)/log(10)
  x = scale_x*T0+y

  label_isotherms_bot <- data.frame(x=x,
                              y=y,
                              hjust=rep(1,length(T0)),
                              label=sprintf("+%d\u00b0",T0))
  label_isotherms_bot[T0<0,]$label <- sprintf("\u2013%d\u00b0",abs(T0[T0<0]))
  label_isotherms_bot <- filter(label_isotherms_bot,x>XMIN)

  T0 = scale_x*seq(10*ceiling(Tmin/10),10*floor(Tmax/10),by=10)-
    (offset_y-scale_y*log(pmin)/log(10))
  T0 <- seq(10*round(min(T0)/10),max(T0),by=10)
  T0 <- T0[T0>-80]
  y = offset_y-scale_y*rep(1,length(T0))*log(pmin)/log(10)
  x = scale_x*T0+y

  label_isotherms_top <- data.frame(x=x,
                                    y=y,
                                    hjust=rep(0,length(T0)),
                                    label=sprintf("+%d\u00b0",T0))
  label_isotherms_top[T0<0,]$label <- sprintf("\u2013%d\u00b0",abs(T0[T0<0]))

  # iso-rsat

  rsat_1 <- c(0.5,seq(1,5),seq(10,80,by=10))*1e-3
  p0_1 <- 685e2*rep(1,length(rsat_1))
  rsat_2 <- c(80,100,120)*1e-3
  p0_2 <- 970e2*rep(1,length(rsat_2))
  rsat_3 <- c(0.1,0.5,seq(1,5),seq(10,50,by=10))*1e-3
  p0_3 <- 435e2*rep(1,length(rsat_3))

  p0 <- c(p0_1,p0_2,p0_3)
  rsat <- c(rsat_1,rsat_2,rsat_3)
  Esat = p0*(1+cst$eps/rsat)^(-1)
  T0 = DewPoint(Esat,tol=1e-3) - cst$Ttrip

  y = offset_y-scale_y*rep(1,length(T0))*log(0.01*p0)/log(10)
  x = scale_x*T0+y

  label_isorsat <- data.frame(x=x,
                              y=y,
                              label=sprintf("%g",1000*rsat))
  label_isorsat <- label_isorsat[label_isorsat$x<XMAX &
                                 label_isorsat$y<YMAX,]

  # Adiabatiques sèches

  T_label <- -43.5
  T0 <- seq(-10,160,by=10)
  p_label = cst$pstd*((T_label+cst$Ttrip)/(T0+cst$Ttrip))^(1/cst$kappad)

  y = offset_y-scale_y*log(0.01*p_label)/log(10)
  x = scale_x*T_label+y

  dx_dy = 1-scale_x*(T_label+cst$Ttrip)*cst$kappad*log(10)/scale_y
  angle = atan(1/dx_dy)*180/pi

  label_dryadiabats <- data.frame(x=x,
                                 y=y,
                                 angle = angle,
                                 label=sprintf("%d\u00b0",T0))
  label_dryadiabats[T0<0,]$label <- sprintf(" \u2013%d\u00b0",abs(T0[T0<0]))
  label_dryadiabats <- filter(label_dryadiabats,y<YMAX)

  # Pseudo-adiabatiques saturées

  T_SPA <- (-28.5)
  label_moistadiabats <- data.frame(x=double(0),
                                   y=double(0),
                                   T0 = double(0),
                                   label=character(0),
                                   angle=double(0))
  nr <- 0
  for(T0 in seq(10*ceiling(min(moistadiabats_up$T0)/10),
                10*floor(max(moistadiabats_up$T0)/10),by=10))
  {
    adiab <- moistadiabats_up[moistadiabats_up$T0==T0,]
    T <- (adiab$x - adiab$y)/scale_x
    ix <- which.min(abs(T-T_SPA))
    if(ix<length(T) & ix>1){
      dy_dx <- (adiab[ix+1,]$y-adiab[ix-1,]$y)/(adiab[ix+1,]$x-adiab[ix-1,]$x)
      nr <- nr+1
      label_moistadiabats[nr,]$x <- adiab[ix,]$x
      label_moistadiabats[nr,]$y <- adiab[ix,]$y
      label_moistadiabats[nr,]$T0 <- T0
      label_moistadiabats[nr,]$label <- sprintf("%d\u00b0",T0)
      label_moistadiabats[nr,]$angle <- atan(dy_dx)*(180./pi) + 90.
    }
  }
  T0 <- label_moistadiabats$T0
  label_moistadiabats[T0<0,]$label <- sprintf(" \u2013%d\u00b0",abs(T0[T0<0]))

  ############## Liste de retour #############

  ema <- list(ggplot2::theme_void(),
#              theme(plot.margin = unit(c(0.25, 0.25, 0.25, 0.25), "cm")),
              ggplot2::coord_cartesian(ratio = 1,
                              clip = "off",
                              #              xlim = c(-30,58.14433)*scale_x,
                              xlim = c(XMIN,XMAX),
                              ylim = c(YMIN,YMAX)
              ),
    ggplot2::geom_path(data=isotherms,aes(x=x,y=y,group=group_segment),
                       linewidth = lw_to_num(isotherms$lw),
                       color = bistre),
    ggplot2::geom_path(data=isobars,aes(x=x,y=y,group=p),
              linewidth = lw_to_num(isobars$lw),
              color = bistre),
    ggplot2::geom_path(data=isorsat,aes(x=x,y=y,group=group_segment),
              linewidth = lw_to_num(isorsat$lw),
              color = bistre,linetype="dashed"),
    ggplot2::geom_path(data=dryadiabats,aes(x=x,y=y,group=group_segment),
              linewidth = lw_to_num(dryadiabats$lw),
              color = vert),
    ggplot2::geom_path(data=moistadiabats_up,aes(x=x,y=y,group=group_segment),
              linewidth = lw_to_num(moistadiabats_up$lw),
              color = vert,linetype="dashed"),
    ggplot2::geom_path(data=moistadiabats_down,aes(x=x,y=y,group=group_segment),
              linewidth = lw_to_num(moistadiabats_down$lw),
              color = vert,linetype="dashed"),
    ggplot2::geom_label(data=label_isobars,aes(x=x,y=y,label=label),
              hjust=label_isobars$hjust,
              fill = "white", linewidth=0,
              label.padding = unit(0.01, "lines"),
              color=bistre,size=size),
    ggplot2::geom_label(data=label_isotherms_bot,aes(x=x,y=y,label=label),
               hjust=label_isotherms_bot$hjust,
               fill = "white", linewidth=0,
               label.padding = unit(0.01, "lines"),
               color=bistre,size=size,angle=45),
    ggplot2::geom_label(data=label_isotherms_top,aes(x=x,y=y,label=label),
               hjust=label_isotherms_top$hjust,
               vjust = 0.1,
               fill = NA, linewidth=0,
               label.padding = unit(0.01, "lines"),
               color=bistre,size=size,angle=45),
    ggplot2::geom_label(data=label_isorsat,aes(x=x,y=y,label=label),
               fill = "white", alpha=0.6,linewidth=0,
               label.padding = unit(0.01, "lines"),
               color=bistre,size=size,fontface="bold"),
    ggplot2::geom_label(data=label_dryadiabats,aes(x=x,y=y,label=label),
               fill = "white", alpha=0.8,linewidth=0,
               label.padding = unit(0.01, "lines"),
               color=vert,angle=label_dryadiabats$angle,
               size=size),
    ggplot2::geom_label(data=label_moistadiabats,
               aes(x=x,y=y,label=label),
               fill = "white", alpha=0.8,linewidth=0,
               label.padding = unit(0.01, "lines"),
               color=vert,angle=label_moistadiabats$angle,
               size=size),
    ggplot2::scale_x_continuous(expand = c(0, 0)),
    ggplot2::scale_y_continuous(expand = c(0, 0))
  )

  return(ema)
}
