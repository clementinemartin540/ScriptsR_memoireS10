#' saturared pseudo-adiabat
#' A function returning the (p,T) saturated pseudo-adiabatic path
#' #'
#' @param p0 values of pressure at the starting points (Pa)
#' @param T0 values of temperature at the starting points (K), same size as p0
#' @param p1 values of pression at end points (Pa)
#' @param T1 values of temperature at end points (K)
#' If p1 is non-empty, then T1 must be empty and conversely; the end point of the path is defined either in pressure or in temperature, but not both
#' @param condens character, "liq" for liquid only, "auto" for automatic switch between liquid and solid condensation
#' @param maxrelchange double, stopping criterion
#' @param Trace boolean, TRUE if we want the whole path, not only the end point
#'
#' @return a list
#' @importFrom rlang is_empty
#' @export
SatPseudoAdiabat <- function(p0,T0,p1,T1,condens="l",maxrelchange=1e-4,Trace=FALSE)
{
# renvoie [ pp1 , TT1 , Trace_p,Trace_T ]

    T = as.vector(T0)
    p = as.vector(p0)

    auto_condens <- FALSE
    Ttrip <- 273.16

    if ( rlang::is_empty(T1) & length(p1)==length(p0) ) {
        to_p_level <- TRUE
        NIT <- ceiling( abs(log(as.vector(p1))-log(as.vector(p0)))/maxrelchange )
        NIT[NIT==0] <- NA
        RELCHANGE <- (log(as.vector(p1))-log(as.vector(p0)))/NIT
    } else {
        if ( rlang::is_empty(p1) & length(T1)==length(T0) ) {
            to_p_level <- FALSE
            NIT <- ceiling( abs(log(as.vector(T1))-log(as.vector(T0)))/maxrelchange )
            NIT[NIT==0] <- NA
            RELCHANGE <- (log(as.vector(T1))-log(as.vector(T0)))/NIT
        } else {
           stop('Either the 3rd or the 4th argument must be an empty array')
        }
    }


    liq <- switch(
      tolower(substring(condens,1,1)),
      "l"= !logical(length(p0)),
      "s"= logical(length(p0)),
      {auto_condens <- TRUE}
    )

    if ( Trace ) {
        Trace_p <- array(dim=c(max(NIT)+1,length(p0)))
        Trace_T <- array(dim=c(max(NIT)+1,length(p0)))
    } else {
        Trace_p <- array(dim=c(0,0))
        Trace_T <- array(dim=c(0,0))
    }

    ###################### RK4 integration for all parcels ######################

    lnp <- log(as.vector(p0))
    lnT <- log(as.vector(T0))
    lnTtrip <- log(Ttrip)

    if (Trace) {
      Trace_p[1,] <- as.vector(p0)
      Trace_T[1,] <- as.vector(T0)
    }

    for (it in 1:max(NIT))
    {
        update <- (it<=NIT)

        if (auto_condens) {
            liq <- (lnT >= lnTtrip)
        }

        dt <- RELCHANGE[update]

        if (to_p_level) {

            EDO1 <- SPA_EDO_symm(as.array(exp(lnp[update])),
                                 as.array(exp(lnT[update])),
                                 as.array(liq[update]))
            k1 <- EDO1$F_p/EDO1$F_T
            EDO2 <- SPA_EDO_symm(as.array(exp(lnp[update]+0.5*dt)),
                                 as.array(exp(lnT[update]+0.5*k1*dt)),
                                 as.array(liq[update]))
            k2 <- EDO2$F_p/EDO2$F_T
            EDO3 <- SPA_EDO_symm(as.array(exp(lnp[update]+0.5*dt)),
                                 as.array(exp(lnT[update]+0.5*k2*dt)),
                                 as.array(liq[update]))
            k3 <- EDO3$F_p/EDO2$F_T
            EDO4 <- SPA_EDO_symm(as.array(exp(lnp[update]+dt)),
                                 as.array(exp(lnT[update]+k3*dt)),
                                 as.array(liq[update]))
            k4 <- EDO4$F_p/EDO4$F_T
            dlnT <- (k1+2*k2+2*k3+k4)*(dt/6)
            lnT[update] <- lnT[update] + dlnT
            lnp[update] <- lnp[update] + dt

        } else {

            EDO1 <- SPA_EDO_symm(as.array(exp(lnp[update])),
                                 as.array(exp(lnT[update])),
                                 as.array(liq[update]))
            k1 <- EDO1$F_T/EDO1$F_p
            EDO2 <- SPA_EDO_symm(as.array(exp(lnp[update]+0.5*k1*dt)),
                                 as.array(exp(lnT[update]+0.5*dt)),
                                 as.array(liq[update]))
            k2 <- EDO2$F_T/EDO2$F_p
            EDO3 <- SPA_EDO_symm(as.array(exp(lnp[update]+0.5*k2*dt)),
                                 as.array(exp(lnT[update]+0.5*dt)),
                                 as.array(liq[update]))
            k3 <- EDO3$F_T/EDO2$F_p
            EDO4 <- SPA_EDO_symm(as.array(exp(lnp[update]+k3*dt)),
                                 as.array(exp(lnT[update]+dt)),
                                 as.array(liq[update]))
            k4 <- EDO4$F_T/EDO4$F_p

            dlnp <- (k1+2*k2+2*k3+k4)*(dt/6)
            lnp[update] <- lnp[update] + dlnp
            lnT[update] <- lnT[update] + dt
        }

        if (Trace) {
            Trace_p[it+1,update] <- exp(lnp[update])
            Trace_T[it+1,update] <- exp(lnT[update])
        }
    }

    pp1 <- array(as.vector(exp(lnp)),dim=dim(as.array(p0)))
    TT1 <- array(as.vector(exp(lnT)),dim=dim(as.array(T0)))

    if (Trace) {
       result <- list(p1=pp1,T1=TT1,Trace_p=Trace_p,Trace_T=Trace_T)
    } else {
      result <- list(p1=pp1,T1=TT1)
    }
    return(result)
}
