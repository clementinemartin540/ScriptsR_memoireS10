#' Lifted condensation level
#'
#' @param p values of pressure (Pa) for parcels whose LCL is requested
#' @param T values of temperature (K) for parcels whose LCL is requested; same size as p
#' @param r values of mixing ratio for parcels whose LCL is requested; same size as p and T
#'   Inputs can be numeric vectors or SpatRasters (single- or multi-layer).
#' @param extras logical; if TRUE (default), also return kappam and Dz_LCL
#'
#' @return a list with element T_LCL and p_LCL, and optionally kappam and Dz_LCL,
#'   same type and number of layers as inputs
#' @export
LCL <- function(p, T, r, extras = FALSE)
{
  RH    <- (p / esat(T, 'liquid')) * r / (cst$eps + r)
  cpm   <- (cst$cpd + r * cst$cpv) / (1 + r)
  Rm    <- (cst$Rd  + r * cst$Rv)  / (1 + r)
  a     <- cpm / Rm + (cst$cpl - cst$cpv) / cst$Rv
  b     <- -(T^(-1)) * (cst$DvapH0 - (cst$cpv - cst$cpl) * cst$Ttrip) / cst$Rv
  cc    <- b / a

  argW  <- (RH^(1/a)) * cc * exp(cc)

  rm(RH, a, b)

  T_LCL <- cc * T / lambertWn_generic(argW)

  rm(cc, argW)

  p_LCL <- p * (T_LCL / T)^(cpm / Rm)

  out <- list(T_LCL = T_LCL, p_LCL = p_LCL)

  if (extras) {
    out$kappam <- Rm / cpm
    out$Dz_LCL <- cpm * (T - T_LCL) / cst$g
  }

  out
}
