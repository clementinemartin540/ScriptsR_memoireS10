#' get thermodynamical constants
#'
#' @return a list
#' @export
get_constants <- function(){
  return(cst)
}
