#' Equivalent potential temperature (Bolton 1980)
#'
#' @param p pressure (Pa); numeric vector or SpatRaster, single- or multi-layer
#' @param T temperature (K); same size as p
#' @param r mixing ratio (kg/kg); same size as p and T
#' @param T_LCL temperature at the LCL (K); same size as p. If NULL (default),
#'   computed internally via \code{\link{LCL}}. Provide it to avoid redundant
#'   computation when T_LCL is already available.
#'
#' @details Implements Bolton (1980) eq. 43.
#'
#' @return equivalent potential temperature (K), same type and number of layers as inputs
#' @references Bolton, D. (1980). The computation of equivalent potential temperature.
#'   \emph{Monthly Weather Review}, 108(7), 1046–1053.
#' @export
theta_e <- function(p, T, r, T_LCL = NULL)
{
  if (is.null(T_LCL))
    T_LCL <- LCL(p, T, r, extras = FALSE)$T_LCL
  kappa_d <- cst$Rd / cst$cpd
  T * (1e5 / p)^(kappa_d * (1 - 0.28 * r)) *
    exp((3376 / T_LCL - 2.54) * r * (1 + 0.81 * r))
}
