#' dew point
#' A function returning the dew point temperature (in K) associated with a given vapor pressure (Pa)
#'
#' @param E values of vapor pressure in Pa
#' @param tol tolerance for the relative error esat(Tdew)/E
#'
#' @return values of dew point temperatures in K
#' @export
DewPoint <- function(E,tol=1e-6)
{
  Tdew = cst$Ttrip+50.*(E>-Inf)
  Tdew[is.na(E)] <- NA_real_
  DvapH = cst$DvapH0 + (cst$cpv-cst$cpl)*(Tdew-cst$Ttrip)
  Edew = 0*Tdew

  update = !is.na(Tdew)

  while(any(update))
  {
    Edew[update] = esat(Tdew[update])
    grad = Edew[update]*DvapH[update]*(Tdew[update]^(-2))/cst$Rv
    Tdew[update] = Tdew[update]-(Edew[update]-E[update])/grad
    DvapH = cst$DvapH0 + (cst$cpv-cst$cpl)*(Tdew-cst$Ttrip)
    update = abs(Edew/E-1)>tol
  }
  return(Tdew)
}
