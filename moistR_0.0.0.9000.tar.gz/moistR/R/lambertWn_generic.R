lambertWn_generic <- function(x, tol = 1e-6, maxit = 100L) {

  # Initialisation W_0 (branche principale, x >= -1/e)
  w0 <- log(1 + abs(x)) * sign(x)

  # Initialisation W_{-1} (branche négative, x dans (-1/e, 0))
  # log(-x) - log(-log(-x)) est l'approximation asymptotique standard
  wn1 <- ifelse(x < 0 & x > -exp(-1),
                log(-x) - log(-log(-x)),
                w0)

  max_delta <- if (inherits(x, "SpatRaster")) {
    function(d) terra::global(abs(d), "max", na.rm = TRUE)[[1]]
  } else {
    function(d) max(abs(d), na.rm = TRUE)
  }

  # Itération de Halley sur W_{-1}
  w <- wn1
  for (i in seq_len(maxit)) {
    ew    <- exp(w)
    num   <- w * ew - x
    den   <- ew * (w + 1) - (w + 2) * num / (2 * w + 2)
    delta <- num / den
    w     <- w - delta
    if (max_delta(delta) < tol) break
  }
  w
}
