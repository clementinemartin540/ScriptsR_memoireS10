#' Moist pseudo-adiabatic lapse rate
#'
#' @param p values of pressure (Pa)
#' @param T values of temperature (K)
#' @param condens character, "liq" for liquid only, "auto" for automatic switch between liquid and solid condensation
#'
#' @return values of moist pseudo-adiabatic lapse rate, same size as p and T
#' @export
MoistAdiabaticLapseRate <- function(p,T,condens="l")
{
  liq <- matrix(TRUE, nrow = nrow(as.matrix(T)),
                      ncol = ncol(as.matrix(T)))

  if(substr(tolower(condens),1,1)!="l")
  {
    liq <- (as.matrix(T)>=cst$Ttrip)
    liq[is.na(liq)] <- FALSE
  }
  spa <- moistR::SPA_EDO_symm(as.matrix(p),as.matrix(T),liq)
  res <- p
  res[] <- spa$Gamma_m
  return(res)
}
