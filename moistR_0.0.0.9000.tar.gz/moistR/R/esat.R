#' saturation vapor pressure
#' A function returning the saturation vapor pressure in Pa for given temperatures
#'
#' @param T values of temperature in K
#' @param condens character string: if starts with "L" or "l", condensed phase is assume to be liquid. If starts with "S" or "s", condensed phase is assumed to be solid. Otherwise, automatic selection of condensed phase is made using temperature value.
#'
#' @return values of saturation vapor pressure, same size as T
#' @export
esat <- function(T, condens = "l") {

  # -- Formule liquide (toujours calculée) -------------------------------------
  e_liq <- cst$ptrip *
    exp((cst$DvapH0 - (cst$cpv - cst$cpl) * cst$Ttrip) *
          (1 / cst$Ttrip - T^(-1)) / cst$Rv) *
    (T / cst$Ttrip)^((cst$cpv - cst$cpl) / cst$Rv)

  # -- Retour immédiat si condensat liquide forcé ------------------------------
  if (substr(tolower(condens), 1, 1) == "l") return(e_liq)

  # -- Formule solide (glace) --------------------------------------------------
  e_ice <- cst$ptrip *
    exp((cst$DsubH0 - (cst$cpv - cst$cps) * cst$Ttrip) *
          (1 / cst$Ttrip - T^(-1)) / cst$Rv) *
    (T / cst$Ttrip)^((cst$cpv - cst$cps) / cst$Rv)

  # -- Sélection pixel par pixel via ifel() ------------------------------------
  # ifel() est vectorisé nativement sur SpatRaster ET sur vecteurs numériques
  terra::ifel(T >= cst$Ttrip, e_liq, e_ice)
}
