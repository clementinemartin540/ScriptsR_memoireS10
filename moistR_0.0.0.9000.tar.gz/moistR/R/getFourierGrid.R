#' Fourier 2D grid associated with a SpatRaster object
#'
#' Returns angular wavenumber matrices (k, l) in rad.m-1, laid out to match the
#' array obtained by `as.array(rast)[, , 1]`, i.e. dimension order [row, col] =
#' [y, x]. The first matrix dimension (rows) carries l (north-south), the second
#' (columns) carries k (east-west). No meshgrid / pracma dependency.
#'
#' The y axis of a projected SpatRaster decreases with row index (row 1 is the
#' northernmost, largest y). A forward FFT of `as.array()` therefore samples y in
#' decreasing order. To keep the physical convention sigma = U*k + V*l with V the
#' true northward wind, we flip the sign of l here, at the source, rather than
#' patching sigma downstream.
#'
#' @param rast a SpatRaster object
#' @import terra
#' @return list(k, l): two matrices of dim c(nrow, ncol), angular wavenumbers (rad/m)
#' @export
getFourierGrid <- function(rast)
{
  nx <- terra::ncol(rast); dx <- terra::xres(rast)
  ny <- terra::nrow(rast); dy <- terra::yres(rast)

  # frequences cycliques signees (cycles/m), convention FFT standard :
  # 0, 1, ..., n/2-1, -n/2, ..., -1  (sur df = 1/(n*d))
  fftfreq <- function(n, d) {
    f <- (0:(n - 1)) / (n * d)
    f[(0:(n - 1)) >= n / 2] <- f[(0:(n - 1)) >= n / 2] - 1 / d
    f
  }

  kx <- 2 * pi * fftfreq(nx, dx)        # rad/m, axe x (colonnes), croissant
  ky <- 2 * pi * fftfreq(ny, dy)        # rad/m, axe y (lignes)

  # L'axe y du raster decroit avec l'indice de ligne -> on inverse le signe de l
  # pour que V > 0 corresponde au vent vers le nord (sigma = U*k + V*l propre).
  ky <- -ky

  # Matrices orientees [row, col] = [y, x], sans meshgrid :
  #   k constant le long des lignes (varie par colonne)
  #   l constant le long des colonnes (varie par ligne)
  k <- matrix(kx, nrow = ny, ncol = nx, byrow = TRUE)   # recyclage par ligne
  l <- matrix(ky, nrow = ny, ncol = nx, byrow = FALSE)  # recyclage par colonne

  list(k = k, l = l)
}
