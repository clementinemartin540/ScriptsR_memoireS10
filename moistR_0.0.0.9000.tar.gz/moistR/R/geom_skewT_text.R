#' geom_text driver for skew-T diagram
#'
#' @param data a data.frame containing at least a column for pressure (in Pa) and temperature (in K)
#' @param mapping mapping aes(x=...,y=...) giving unskewed coordinates (p,T)
#' @param scale_x x-axis stretch factor
#' @param ... extra arguments for geom_point()
#'
#' @import ggplot2
#' @importFrom rlang as_name
#' @importFrom rlang sym
#' @return a ggplot layer
#' @export
geom_skewT_text <- function(mapping = aes(), data, scale_x = 1, ...) {

  scale_y <- 254.8 * (scale_x / 2.91)
  offset_y  <- scale_y*log(1000)/log(10)
  Ttrip <- 273.16

  # Vérifier que data est fourni
  if (missing(data)) stop("You must provide a data.frame")

  # Extraire les noms des colonnes x et y
  x_name <- rlang::as_name(mapping$x)
  y_name <- rlang::as_name(mapping$y)

  # Créer des colonnes transformées dans un nouveau data.frame
  df_trans <- data
  df_trans$x_skew <- scale_x * (df_trans[[x_name]] - Ttrip) + offset_y - scale_y * log(0.01 * df_trans[[y_name]])/log(10)
  df_trans$y_skew <- offset_y - scale_y * log(0.01 * df_trans[[y_name]])/log(10)

  # Créer un nouveau mapping pour le geom
  new_mapping <- mapping
  new_mapping$x <- rlang::sym("x_skew")
  new_mapping$y <- rlang::sym("y_skew")

  # Retourner le geom_point
  ggplot2::geom_text(data = df_trans, mapping = new_mapping, ...)
}
